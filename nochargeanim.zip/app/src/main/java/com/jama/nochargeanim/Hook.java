package com.jama.nochargeanim;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

public class Hook implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        ClassLoader cl = lp.classLoader;
        try {
            XposedHelpers.setStaticBooleanField(
                    XposedHelpers.findClass("com.miui.charge.ChargeUtils", cl),
                    "sChargeAnimationDisabled", true);
        } catch (Throwable t) { XposedBridge.log("nochargeanim flag: " + t); }
        try {
            Class<?> c = XposedHelpers.findClass("com.miui.charge.MiuiChargeController", cl);
            XposedBridge.hookAllMethods(c, "shouldShowChargeAnim", XC_MethodReplacement.returnConstant(false));
            XposedBridge.hookAllMethods(c, "showChargeAnimation", XC_MethodReplacement.DO_NOTHING);
        } catch (Throwable t) { XposedBridge.log("nochargeanim controller: " + t); }
        try {
            Class<?> v = XposedHelpers.findClass("com.miui.charge.container.MiuiChargeAnimationView", cl);
            XposedBridge.hookAllMethods(v, "addChargeView", XC_MethodReplacement.DO_NOTHING);
        } catch (Throwable t) { XposedBridge.log("nochargeanim view: " + t); }
    }
}
